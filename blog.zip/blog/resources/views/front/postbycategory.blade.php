@extends('front.layout.layout')

@section('content')
<div class="row d-flex">
@foreach ($data as $posts)

<div class="col-md-4 d-flex ftco-animate">
    <div class="blog-entry justify-content-end">
        <a href="{{ url('/blog/single-post/'.$posts->title) }}" class="block-20" style="background-image: url('{{ asset('images/'.$posts->image)}}');">
        </a>
        <div class="text mt-3 float-right d-block">
        <div class="d-flex align-items-center mb-3 meta">
            <p class="mb-0">
                <span class="mr-2">{{ date('M jS Y', strtotime($posts->updated_at)) }}</span>
                <a href="#" class="mr-2">{{ $posts->name }}</a>
                <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
            </p>
        </div>
        <h3 class="heading"><a href="{{ url('/blog/single-post/'.$posts->title) }}">{{ $posts->title }}</a></h3>
        <p >{{ $posts->description }}</p>
        </div>
    </div>
</div>
@endforeach
</div>
{{ $data->links() }}
@endsection
