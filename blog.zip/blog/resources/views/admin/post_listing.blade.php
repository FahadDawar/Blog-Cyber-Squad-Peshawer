@extends('admin.layout.layout')
@yield('POST - LISTING')

@section('content')
{{-- @foreach ($posts['data'] as $post)
    {{ $post->name }}
@endforeach --}}
<?php


// echo "<pre>"; print_r($data);
// die; ?>

<div class="col-md-12 col-sm-12">
    <section class="section">
        @if (Session::get('msg'))
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{Session::get('msg') }}</div>
        @endif
         @if (Session::get('success'))
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> {{Session::get('success') }}</div>
        @endif
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Post Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>TITLE</th>
                                    <th>DESCRIPTION</th>
                                    <th>CATEGORY</th>
                                    <th>AUTHER</th>
                                    <th>IMAGE</th>
                                    <th>ACTION</th>

                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($data as $post)
                                        <tr>
                                    <td class="text-bold-500" >{{ $post->id }}</td>
                                    <td class="text-bold-500" >{{ $post->title }}</td>
                                    <td class="text-bold-500" >{{ $post->description }}</td>
                                    <td class="text-bold-500" >{{ $post->cat_name }}</td>
                                    <td class="text-bold-500" >{{ $post->name }}</td>

                                    <td class="text-bold-500" >
                                        <img src="{{ asset('images/'.$post->image) }}" alt="" style="width: 90px;">
                                       </td>

                                   <td>
                                       <a href="{{ url('/admin-csp-blog/post/edit/'.$post->id) }}"  class="btn btn-outline-success btn-sm">Edit</a>
                                       <form action="{{ url('/admin-csp-blog/post/delete/'.$post->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-outline-danger btn-sm mt-2">Delete</button>
                                        </form>
                                   </td>
                                </tr>
                           @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

@endsection