@extends('admin.layout.layout')
@yield('ADD - USER')

@section('content')

<div class="row">
<div class="col-md-4 ">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Add Category</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" method="POST" enctype="multipart/form-data" action="{{ route('admin-csp-blog.add.category') }}">
                         @csrf

                        @if (Session::get('cat_add_success'))
                            <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> {{ Session::get('cat_add_success') }}</div>
                            @endif
                       @if ($errors->any())
                           @foreach ($errors->all() as $error)
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{ $error }}</div>
                           @endforeach

                       @endif
                       @if (Session::get('error'))
                            <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i>
                       {{ Session::get('error') }}</div>
                       @endif
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="first-name-icon"> Category</label>
                                        <div class="position-relative">
                                            <input type="text" class="form-control" placeholder="Name" required name="name" id="">
                                            <div class="form-control-icon">
                                                {{-- <i class="fas fa-book-open"></i> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
 </div>

<div class="col-md-8 ">
    <section class="section">
        @if (Session::get('deleted'))
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{Session::get('deleted') }}</div>
        @endif
         @if (Session::get('success'))
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> {{Session::get('success') }}</div>
        @endif
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Category Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($cats as $cat)
                                        <tr>
                                    <td class="text-bold-500">{{ $cat->id }}</td>
                                    <td class="text-bold-500">{{ $cat->cat_name }}</td>

                                    <td>
                                          <form class="pt-2" action="{{ route('admin-csp-blog.cat.delete') }}" method="POST">
                                                @csrf
                                                  <input type="hidden" name="id" value="{{ $cat->id }}" id="">
                                            <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                            </form>
                                            {{-- <form class="pt-2" action="{{ route('admin-csp-blog.cat.edit') }}" method="POST">
                                                @csrf
                                                  <input type="hidden" name="id" value="{{ $cat->id }}" id="">
                                            <button type="submit" class="btn btn-outline-success btn-sm">Edit</button>
                                            </form> --}}
                                            <a href="{{ url('/admin-csp-blog/edit/category/'.$cat->id) }}" class="btn btn-outline-success btn-sm mt-2">Edit</a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

</div>
</div>
@endsection