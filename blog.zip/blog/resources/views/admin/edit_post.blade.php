@extends('admin.layout.layout')
@yield('ADD - USER')

@section('content')

<div class="row">
<div class="col-md-12 sm-12">
<section id="multiple-column-form">
    <div class="row match-height">
        <div class="col-12">
            <div class="card">
                 @if ($errors->any())
                           @foreach ($errors->all() as $error)
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{ $error }}</div>
                           @endforeach

                       @endif
                       @if (Session::get('success'))
                           <div class="alert alert-light-succes color-succes"><i class="bi bi-tick-circle"></i> {{ Session::get('seccess') }}</div>
                       @endif
                <div class="card-header">
                    <h4 class="card-title">Add Post</h4>
                </div>
                <div class="card-content">
                    <div class="card-body">

                        <form action="{{ url('/admin-csp-blog/post/update/'.$post[0]->id) }}" enctype="multipart/form-data" class="form" method="POST" >
                            @csrf
                            <div class="row">
                                <div class="row">
                                    <div class="col-md-8 col-12">
                                        <div class="form-group">
                                            <label for="first-name-column">Title</label>
                                            <input type="text" id="first-name-column" class="form-control" value="{{ $post[0]->title }}" name="title">
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-12">

                                        <div class="form-group">
                                            <input type="hidden" name="auther_id" value="{{ Session::get('ADMIN_CSP_BLOG_ID') }}" id="">
                                            <label for="first-name-column">Category</label>
                                            <select name="cetegory"  class="form-select"  id="">
                                                <option value="">Options</option>
                                                @foreach ($cat as $ca)
                                                <option value="{{ $ca->id }}">{{ $ca->cat_name }}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                </div>
                               <div class="row">
                                   <div class="col-md-12 col-sm-12">
                                    <div class="form-group with-title mb-3">
                                        <textarea class="form-control" id="exampleFormControlTextarea1" name="description" rows="3">{{ $post[0]->description }}</textarea>
                                        <label>Your experience</label>
                                    </div>
                                   </div>
                               </div>
                                <div class="col-md-6 col-12">
                                    <div class="form-group">
                                        <label for="email-id-column">Image</label>
                                        <input type="file" name="image" class="form-control" name="email-id-column">
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Publish</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

 </div>
</div>
@endsection