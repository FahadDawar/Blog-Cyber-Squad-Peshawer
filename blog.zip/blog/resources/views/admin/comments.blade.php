 @extends('admin.layout.layout')

 @section('title', 'BLOG | Comments')

@section('content')
{{-- @foreach ($posts['data'] as $post)
    {{ $post->name }}
@endforeach --}}

<div class="col-md-12 col-sm-12">
    <section class="section">
        @if (Session::get('commentdeleted'))
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{Session::get('commentdeleted') }}</div>
        @endif
         @if (Session::get('success'))
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> {{Session::get('success') }}</div>
        @endif
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Comments Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>NAME</th>
                                    <th>EMAIL</th>
                                    <th>WEBSITE</th>
                                    <th>COMMENT</th>
                                    <th>ACTION</th>

                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($data as $comment)
                                        <tr>
                                    <td class="text-bold-500" >{{ $comment->id }}</td>
                                    <td class="text-bold-500" >{{ $comment->uname }}</td>
                                    <td class="text-bold-500" >{{ $comment->email }}</td>
                                    <td class="text-bold-500" >{{ $comment->website }}</td>
                                    <td class="text-bold-500" >{{ $comment->comment }}</td>
                                   <td>

                                       <form action="{{ url('/admin-csp-blog/comment/delete/'.$comment->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-outline-danger btn-sm mt-2">Delete</button>
                                        </form>
                                   </td>
                                 <td>
                                       @if ($comment->status == 1)
                                       <a href="{{ url('/admin-csp-blog/comment/update/'.'pending/'.$comment->id) }}"  class="btn btn-outline-success btn-sm">Approved</a>
                                    @else
                                        <a href="{{ url('/admin-csp-blog/comment/update/'.'approve/'.$comment->id) }}"  class="btn btn-outline-warning btn-sm">Pending</a>
                                   @endif
                                 </td>
                                </tr>
                           @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

@endsection