@extends('admin.layout.layout')
@yield('ADD - USER')

@section('content')

<div class="row">
<div class="col-md-4 ">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Register User</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" method="POST" enctype="multipart/form-data" action="{{ route('admin-csp-blog.add.user') }}">

                         @csrf
                        @if (Session::get('admin_user_add_error'))
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{ Session::get('admin_user_add_error') }}</div>
                        @endif
                        @if (Session::get('admin_user_add_success'))
                            <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> {{ Session::get('admin_user_add_success') }}</div>
                            @endif
                       @if ($errors->any())
                           @foreach ($errors->all() as $error)
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{ $error }}</div>
                           @endforeach

                       @endif
                       @if (Session::get('error'))
                            <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i>
                       {{ Session::get('error') }}</div>
                       @endif
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="first-name-icon"> Name</label>
                                        <div class="position-relative">
                                            <input type="text" class="form-control" placeholder="Name" required name="name" id="first-name-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-person"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">

                                    <div class="form-group has-icon-left">
                                        <label for="email-id-icon">Email</label>
                                        <div class="position-relative">
                                            <input type="email" required name="email" class="form-control" placeholder="Email" id="email-id-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-envelope"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group has-icon-left">
                                        <label for="">User Type</label>
                                        <div class="input-group mb-3">
                                            <label class="input-group-text" for="inputGroupSelect01">Options</label>
                                            <select class="form-select"  name="usertype" id="inputGroupSelect01">
                                                <option value="">Choose...</option>
                                                <option value="admin">Admin</option>
                                                <option value="auther">Auther</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="password-id-icon">Password</label>
                                        <div class="position-relative">
                                            <input type="password" required name="password" class="form-control" placeholder="Password" id="password-id-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-lock"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="password-id-icon">Confirm</label>
                                        <div class="position-relative">
                                            <input type="password" name="confirm_password" required class="form-control" placeholder="Password" id="password-id-icon">
                                             <input type="hidden" name="status" id="" value="1">
                                            <div class="form-control-icon">
                                                <i class="bi bi-lock"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
 </div>

<div class="col-md-8 ">
    <section class="section">
        @if (Session::get('msg'))
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> {{Session::get('msg') }}</div>
        @endif
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">User Details</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>NAME</th>
                                    <th>EMAIL</th>
                                    <th>TYPE</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data as $user)
                                        <tr>
                                    <td class="text-bold-500">{{ $user->name }}</td>
                                    <td class="text-bold-500">{{ $user->email }}</td>
                                    <td class="text-bold-500">{{ $user->role }}</td>
                                    <td>
                                    @if ($user->status == 1)
                                   <span class="badge bg-light-success py-2 px-3">Active</span>
                                    @else
                                   <span class="badge bg-light-danger py-2 px-3">Bane</span>
                                    @endif
                                    </td>
                                    <td>

                                        <form action="{{ url('/admin-csp-blog/user/status/'.$user->id) }}" method="POST">
                                            @csrf
                                             <input type="hidden" name="id" value="{{ Session::get('ADMIN_CSP_BLOG_ID') }}">
                                            @if ($user->status == 1)
                                             <input type="hidden" name="name" value="bane" id="">

                                              <button type="submit" class="btn btn-outline-warning btn-sm">
                                              Change Status
                                             </button>
                                             @else
                                             <input type="hidden" name="name" value="active" id="">
                                             {{-- <input type="hidden" name="id" value="{{ $user->id }}" id=""> --}}

                                               <button type="submit" class="btn btn-outline-warning btn-sm">
                                               Change Status
                                              </button>

                                            @endif
                                         </form>
                                          <form class="pt-2" action="{{ route('admin-csp-blog.user.delete') }}" method="POST">
                                                @csrf
                                                  <input type="hidden" name="deletid" value="{{ $user->id }}" id="">
                                                 <input type="hidden" name="activeid" value="{{ Session::get('ADMIN_CSP_BLOG_ID') }}">

                                            <button class="btn btn-outline-danger btn-sm">Delete</button>
                                            </form>

                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

</div>
</div>
@endsection