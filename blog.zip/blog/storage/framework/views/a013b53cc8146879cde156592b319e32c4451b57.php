</div>
<script src="<?php echo e(asset('admin/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>
</body>

</html><?php /**PATH F:\laravel\blog\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>