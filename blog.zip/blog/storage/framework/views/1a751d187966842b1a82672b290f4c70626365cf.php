 

 <?php $__env->startSection('title', 'BLOG | Comments'); ?>

<?php $__env->startSection('content'); ?>


<div class="col-md-12 col-sm-12">
    <section class="section">
        <?php if(Session::get('commentdeleted')): ?>
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e(Session::get('commentdeleted')); ?></div>
        <?php endif; ?>
         <?php if(Session::get('success')): ?>
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> <?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Comments Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>NAME</th>
                                    <th>EMAIL</th>
                                    <th>WEBSITE</th>
                                    <th>COMMENT</th>
                                    <th>ACTION</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                    <td class="text-bold-500" ><?php echo e($comment->id); ?></td>
                                    <td class="text-bold-500" ><?php echo e($comment->uname); ?></td>
                                    <td class="text-bold-500" ><?php echo e($comment->email); ?></td>
                                    <td class="text-bold-500" ><?php echo e($comment->website); ?></td>
                                    <td class="text-bold-500" ><?php echo e($comment->comment); ?></td>
                                   <td>

                                       <form action="<?php echo e(url('/admin-csp-blog/comment/delete/'.$comment->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm mt-2">Delete</button>
                                        </form>
                                   </td>
                                 <td>
                                       <?php if($comment->status == 1): ?>
                                       <a href="<?php echo e(url('/admin-csp-blog/comment/update/'.'pending/'.$comment->id)); ?>"  class="btn btn-outline-success btn-sm">Approved</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/admin-csp-blog/comment/update/'.'approve/'.$comment->id)); ?>"  class="btn btn-outline-warning btn-sm">Pending</a>
                                   <?php endif; ?>
                                 </td>
                                </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/admin/comments.blade.php ENDPATH**/ ?>