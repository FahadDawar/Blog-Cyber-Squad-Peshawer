
<?php echo $__env->yieldContent('ADD - USER'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-md-4 ">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Register User</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin-csp-blog.add.user')); ?>">

                         <?php echo csrf_field(); ?>
                        <?php if(Session::get('admin_user_add_error')): ?>
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e(Session::get('admin_user_add_error')); ?></div>
                        <?php endif; ?>
                        <?php if(Session::get('admin_user_add_success')): ?>
                            <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> <?php echo e(Session::get('admin_user_add_success')); ?></div>
                            <?php endif; ?>
                       <?php if($errors->any()): ?>
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e($error); ?></div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       <?php endif; ?>
                       <?php if(Session::get('error')): ?>
                            <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i>
                       <?php echo e(Session::get('error')); ?></div>
                       <?php endif; ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="first-name-icon"> Name</label>
                                        <div class="position-relative">
                                            <input type="text" class="form-control" placeholder="Name" required name="name" id="first-name-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-person"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">

                                    <div class="form-group has-icon-left">
                                        <label for="email-id-icon">Email</label>
                                        <div class="position-relative">
                                            <input type="email" required name="email" class="form-control" placeholder="Email" id="email-id-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-envelope"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group has-icon-left">
                                        <label for="">User Type</label>
                                        <div class="input-group mb-3">
                                            <label class="input-group-text" for="inputGroupSelect01">Options</label>
                                            <select class="form-select"  name="usertype" id="inputGroupSelect01">
                                                <option value="">Choose...</option>
                                                <option value="admin">Admin</option>
                                                <option value="auther">Auther</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="password-id-icon">Password</label>
                                        <div class="position-relative">
                                            <input type="password" required name="password" class="form-control" placeholder="Password" id="password-id-icon">
                                            <div class="form-control-icon">
                                                <i class="bi bi-lock"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-12">
                                    <div class="form-group has-icon-left">
                                        <label for="password-id-icon">Confirm</label>
                                        <div class="position-relative">
                                            <input type="password" name="confirm_password" required class="form-control" placeholder="Password" id="password-id-icon">
                                             <input type="hidden" name="status" id="" value="1">
                                            <div class="form-control-icon">
                                                <i class="bi bi-lock"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
 </div>

<div class="col-md-8 ">
    <section class="section">
        <?php if(Session::get('msg')): ?>
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e(Session::get('msg')); ?></div>
        <?php endif; ?>
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">User Details</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>NAME</th>
                                    <th>EMAIL</th>
                                    <th>TYPE</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                    <td class="text-bold-500"><?php echo e($user->name); ?></td>
                                    <td class="text-bold-500"><?php echo e($user->email); ?></td>
                                    <td class="text-bold-500"><?php echo e($user->role); ?></td>
                                    <td>
                                    <?php if($user->status == 1): ?>
                                   <span class="badge bg-light-success py-2 px-3">Active</span>
                                    <?php else: ?>
                                   <span class="badge bg-light-danger py-2 px-3">Bane</span>
                                    <?php endif; ?>
                                    </td>
                                    <td>

                                        <form action="<?php echo e(url('/admin-csp-blog/user/status/'.$user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                             <input type="hidden" name="id" value="<?php echo e(Session::get('ADMIN_CSP_BLOG_ID')); ?>">
                                            <?php if($user->status == 1): ?>
                                             <input type="hidden" name="name" value="bane" id="">

                                              <button type="submit" class="btn btn-outline-warning btn-sm">
                                              Change Status
                                             </button>
                                             <?php else: ?>
                                             <input type="hidden" name="name" value="active" id="">
                                             

                                               <button type="submit" class="btn btn-outline-warning btn-sm">
                                               Change Status
                                              </button>

                                            <?php endif; ?>
                                         </form>
                                          <form class="pt-2" action="<?php echo e(route('admin-csp-blog.user.delete')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                  <input type="hidden" name="deletid" value="<?php echo e($user->id); ?>" id="">
                                                 <input type="hidden" name="activeid" value="<?php echo e(Session::get('ADMIN_CSP_BLOG_ID')); ?>">

                                            <button class="btn btn-outline-danger btn-sm">Delete</button>
                                            </form>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/admin/add_user.blade.php ENDPATH**/ ?>