
<?php echo $__env->yieldContent('POST - LISTING'); ?>

<?php $__env->startSection('content'); ?>

<?php


// echo "<pre>"; print_r($data);
// die; ?>

<div class="col-md-12 col-sm-12">
    <section class="section">
        <?php if(Session::get('msg')): ?>
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e(Session::get('msg')); ?></div>
        <?php endif; ?>
         <?php if(Session::get('success')): ?>
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> <?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Post Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>TITLE</th>
                                    <th>DESCRIPTION</th>
                                    <th>CATEGORY</th>
                                    <th>AUTHER</th>
                                    <th>IMAGE</th>
                                    <th>ACTION</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                    <td class="text-bold-500" ><?php echo e($post->id); ?></td>
                                    <td class="text-bold-500" ><?php echo e($post->title); ?></td>
                                    <td class="text-bold-500" ><?php echo e($post->description); ?></td>
                                    <td class="text-bold-500" ><?php echo e($post->cat_name); ?></td>
                                    <td class="text-bold-500" ><?php echo e($post->name); ?></td>

                                    <td class="text-bold-500" >
                                        <img src="<?php echo e(asset('images/'.$post->image)); ?>" alt="" style="width: 90px;">
                                       </td>

                                   <td>
                                       <a href="<?php echo e(url('/admin-csp-blog/post/edit/'.$post->id)); ?>"  class="btn btn-outline-success btn-sm">Edit</a>
                                       <form action="<?php echo e(url('/admin-csp-blog/post/delete/'.$post->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm mt-2">Delete</button>
                                        </form>
                                   </td>
                                </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/admin/post_listing.blade.php ENDPATH**/ ?>