

<?php $__env->startSection('content'); ?>
<div class="row d-flex">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-4 d-flex ftco-animate">
    <div class="blog-entry justify-content-end">
        <a href="<?php echo e(url('/blog/single-post/'.$posts->title)); ?>" class="block-20" style="background-image: url('<?php echo e(asset('images/'.$posts->image)); ?>');">
        </a>
        <div class="text mt-3 float-right d-block">
        <div class="d-flex align-items-center mb-3 meta">
            <p class="mb-0">
                <span class="mr-2"><?php echo e(date('M jS Y', strtotime($posts->updated_at))); ?></span>
                <a href="#" class="mr-2"><?php echo e($posts->name); ?></a>
                <a href="#" class="meta-chat"><span class="icon-chat"></span> 3</a>
            </p>
        </div>
        <h3 class="heading"><a href="<?php echo e(url('/blog/single-post/'.$posts->title)); ?>"><?php echo e($posts->title); ?></a></h3>
        <p ><?php echo e($posts->description); ?></p>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div>
<?php echo e($data->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/front/index.blade.php ENDPATH**/ ?>