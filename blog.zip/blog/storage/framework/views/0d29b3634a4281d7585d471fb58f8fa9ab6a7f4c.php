<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <title>Orbailix - Blog</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/open-iconic-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/magnific-popup.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/aos.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('front/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/icomoon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/style.css')); ?>">
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">


    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar ftco-navbar-light site-navbar-target" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Orbailix</a>
	      <button class="navbar-toggler js-fh5co-nav-toggle fh5co-nav-toggle" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav nav ml-auto">
	          
	          <li class="nav-item"><a href="<?php echo e(url('/')); ?>" class="nav-link"><span>Blog</span></a></li>
                
                <li class="nav-item dropdown me-3">
                    <a class="nav-link active dropdown-toggle" href="#" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <i class='bi bi-bell bi-sub fs-4 text-gray-600'></i>
                        Categories
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                        <li>
                            <h6 class="dropdown-header">Categories</h6>
                        </li>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('/blog/category/'.$catlist->cat_name.'/'.$catlist->id)); ?>" class="dropdown-item"><?php echo e($catlist->cat_name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
              
	          <li class="nav-item"><a href="#contact-section" class="nav-link"><span>Contact</span></a></li>
               <li class="nav-item"><a href="#about-section" class="nav-link"><span>About</span></a></li>

	        </ul>
	      </div>
	    </div>
	  </nav>




  <section class="ftco-section" id="blog-section">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-5">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h1 class="big big-2">Blog</h1>
            <h2 class="mb-4">Our Blog</h2>
            <p>Orbailix where we come with new solutions for the problems</p>
          </div>
        </div>



           <?php $__env->startSection('content'); ?>

           <?php echo $__env->yieldSection(); ?>


      </div>
    </section>





    <footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About</h2>
              <p>Orbailix is a software company based on web development and cyber security that come with new anovations and solve problems</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-4">
              <h2 class="ftco-heading-2">Links</h2>
              <ul class="list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>"><span class="icon-long-arrow-right mr-2"></span>Home</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>About</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Services</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Projects</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Contact</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Services</h2>
              <ul class="list-unstyled">
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Web Design</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Web Development</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Graphic Design</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Cyber Security</a></li>
                <li><a href="#"><span class="icon-long-arrow-right mr-2"></span>Business Strategy</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">241, Deans Trade Center, Saddar Bazar, Peshawer, KP, 25000, Pakistan</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+92 91 5603 019</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info.orbailix@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Orbailix
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>



  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.easing.1.3.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.stellar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.magnific-popup.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/aos.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/jquery.animateNumber.min.js')); ?>"></script>
  <script src="<?php echo e(asset('front/js/scrollax.min.js')); ?>"></script>

  <script src="<?php echo e(asset('front/js/main.js')); ?>"></script>

  </body>
</html><?php /**PATH F:\laravel\blog\resources\views/front/layout/layout.blade.php ENDPATH**/ ?>