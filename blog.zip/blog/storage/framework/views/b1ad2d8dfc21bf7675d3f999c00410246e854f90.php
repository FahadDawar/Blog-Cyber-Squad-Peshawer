
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4 ">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Edit Category</h4>
            </div>
            <div class="card-content">
                <div class="card-body">

                    <form action="<?php echo e(url('/admin-csp-blog/update/category/'.$data[0]->id)); ?>" class="form form-vertical" method="POST" >
                         <?php echo csrf_field(); ?>

                       <?php if($errors->any()): ?>
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e($error); ?></div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       <?php endif; ?>
                       <?php if(Session::get('error')): ?>
                            <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i>
                       <?php echo e(Session::get('error')); ?></div>
                       <?php endif; ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="first-name-icon"> Category</label>
                                        <div class="position-relative">
                                            
                                            <input type="text" class="form-control" value="<?php echo e($data[0]->cat_name); ?>"  name="name" id="">
                                            <div class="form-control-icon">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Update</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
 </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/admin/edit_category.blade.php ENDPATH**/ ?>