 <div id="main-content">
      <?php echo $__env->yieldContent('content'); ?>
 </div><?php /**PATH F:\laravel\blog\resources\views/admin/layout/maincontent.blade.php ENDPATH**/ ?>