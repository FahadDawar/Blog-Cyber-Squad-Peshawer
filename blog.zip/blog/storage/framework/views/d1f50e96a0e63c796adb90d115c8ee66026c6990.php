<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'BLOG | Cyber Squad Peshawer'); ?></title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/bootstrap.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/app.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/images/favicon.svg" type="image/x-icon')); ?>">
</head>

<body>
   <div id="app">
       
    <div id="sidebar" class="active">
            <div class="sidebar-wrapper active">
                <div class="sidebar-header">
                    <div class="d-flex justify-content-between">
                        <div class="logo">
                            <a href="<?php echo e(route('admin.csp.blog')); ?>"><img src="<?php echo e(asset('admin/assets/images/logo/logo.png')); ?>" alt="Logo" srcset=""></a>
                        </div>
                        <div class="toggler">
                            <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sidebar-menu">
                    <ul class="menu">
                        <li class="sidebar-title">Menu</li>

                        <li class="sidebar-item  ">
                            <a href="<?php echo e(route('admin.csp.blog')); ?>" class='sidebar-link'>
                                <i class="bi bi-grid-fill"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>

                        <li class="sidebar-item  has-sub">
                            <a href="#" class='sidebar-link'>
                                <i class="bi bi-stack"></i>
                                <span>Manage Post</span>
                            </a>
                            <ul class="submenu ">
                                <li class="submenu-item ">
                                    <a href="<?php echo e(route('admin.csp.blog.add_category')); ?>">Add Category</a>
                                </li>

                                <li class="submenu-item ">
                                    <a href="<?php echo e(route('admin-csp-blog.add.post')); ?>">Add Post</a>
                                </li>
                                <li class="submenu-item ">
                                    <a href="<?php echo e(route('admin-csp-blog.list.post')); ?>">Post Listing</a>
                                </li>
                            </ul>
                        </li>

                        


                        <?php if(Session::get('ADMIN_CSP_BLOG_ROLE') == 'admin'): ?>

                            <li class="sidebar-item  ">
                            <a href="<?php echo e(url('/admin-csp-blog/comments/')); ?>" class='sidebar-link'><i class="bi bi-person"></i>
                                <span>Comments</span>
                            </a>
                        </li>
                             <li class="sidebar-item  ">
                            <a href="<?php echo e(route('admin.csp.blog.add_user')); ?>" class='sidebar-link'>
                                <i class="bi bi-person"></i>
                                <span>Register User</span>
                            </a>
                            </li>

                        <?php endif; ?>



                    </ul>
                </div>
                <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
            </div>
        </div>

    </div>
    
    
     <div id="main" class='layout-navbar'>
            <header class='mb-3'>
                <nav class="navbar navbar-expand navbar-light ">
                    <div class="container-fluid">
                        <a href="#" class="burger-btn d-block">
                            <i class="bi bi-justify fs-3"></i>
                        </a>

                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                                
                                
                            </ul>
                            <div class="dropdown">
                                <a href="#" data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="user-menu d-flex">
                                        <div class="user-name text-end me-3">
                                            <h6 class="mb-0 text-gray-600"><?php echo e(Session::get('ADMIN_NAME_CSP_BLOG')); ?></h6>
                                            <p class="mb-0 text-sm text-gray-600">Administrator</p>
                                        </div>
                                        <div class="user-img d-flex align-items-center">
                                            <div class="avatar avatar-md">
                                                <img src="<?php echo e(asset('admin/assets/images/faces/2.jpg')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton">
                                    <li>
                                        <h6 class="dropdown-header">Hello, <?php echo e(Session::get('ADMIN_NAME_CSP_BLOG')); ?></h6>
                                    </li>
                                    
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.csp.blog._logout')); ?>"><i
                                                class="icon-mid bi bi-box-arrow-left me-2"></i> Logout</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
            </header>
            <div id="main-content">
           <?php $__env->startSection('content'); ?>
           <?php echo $__env->yieldSection(); ?>
           </div>
        </div>
    
    <script src="<?php echo e(asset('admin/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH F:\laravel\blog\resources\views/admin/layout/layout.blade.php ENDPATH**/ ?>