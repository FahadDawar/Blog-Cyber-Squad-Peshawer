
<?php echo $__env->yieldContent('ADD - USER'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-md-4 ">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Add Category</h4>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <form class="form form-vertical" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin-csp-blog.add.category')); ?>">
                         <?php echo csrf_field(); ?>

                        <?php if(Session::get('cat_add_success')): ?>
                            <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> <?php echo e(Session::get('cat_add_success')); ?></div>
                            <?php endif; ?>
                       <?php if($errors->any()): ?>
                           <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e($error); ?></div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                       <?php endif; ?>
                       <?php if(Session::get('error')): ?>
                            <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i>
                       <?php echo e(Session::get('error')); ?></div>
                       <?php endif; ?>
                        <div class="form-body">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="first-name-icon"> Category</label>
                                        <div class="position-relative">
                                            <input type="text" class="form-control" placeholder="Name" required name="name" id="">
                                            <div class="form-control-icon">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12 d-flex justify-content-end">
                                    <button type="submit" class="btn btn-primary me-1 mb-1">Save</button>
                                    <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
 </div>

<div class="col-md-8 ">
    <section class="section">
        <?php if(Session::get('deleted')): ?>
             <div class="alert alert-light-danger color-danger"><i class="bi bi-exclamation-circle"></i> <?php echo e(Session::get('deleted')); ?></div>
        <?php endif; ?>
         <?php if(Session::get('success')): ?>
             <div class="alert alert-light-success color-success"><i class="bi bi-check-circle"></i> <?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
    <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Category Listing</h4>
                </div>
                <div class="card-content">

                    <!-- table striped -->
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                    <td class="text-bold-500"><?php echo e($cat->id); ?></td>
                                    <td class="text-bold-500"><?php echo e($cat->cat_name); ?></td>

                                    <td>
                                          <form class="pt-2" action="<?php echo e(route('admin-csp-blog.cat.delete')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                  <input type="hidden" name="id" value="<?php echo e($cat->id); ?>" id="">
                                            <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                            </form>
                                            
                                            <a href="<?php echo e(url('/admin-csp-blog/edit/category/'.$cat->id)); ?>" class="btn btn-outline-success btn-sm mt-2">Edit</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

</section>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel\blog\resources\views/admin/add_category.blade.php ENDPATH**/ ?>