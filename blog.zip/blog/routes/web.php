<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\FrontController;
use App\Http\Controllers\CommentController;




use App\Models\Category;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::post('/admin-csp-blog/auth', [AdminController::class, 'Admin_auth'])->name('admin.csp.blog.auth');
Route::get('/admin-csp-blog/_logout', [AdminController::class, 'logout'])->name('admin.csp.blog._logout');
Route::get('/admin-csp-blog/login', [AdminController::class, 'login']);

Route::group(['middleware' => ['AuthCheck']], function () {
    // Admin
    Route::post('/admin-csp-blog/add/user', [AdminController::class, 'store'])->name('admin-csp-blog.add.user');
    Route::post('/admin-csp-blog/user/delete/', [AdminController::class, 'destroy'])->name('admin-csp-blog.user.delete');
    Route::post('/admin-csp-blog/user/status/{id}', [AdminController::class, 'editStatus']);
    Route::get('/admin-csp-blog/', [AdminController::class, 'index'])->name('admin.csp.blog');
    Route::get('/admin-csp-blog/add_user', [AdminController::class, 'User_view'])->name('admin.csp.blog.add_user');
    //    Category
    Route::get('/admin-csp-blog/add_category', [CategoryController::class, 'index'])->name('admin.csp.blog.add_category');
    Route::post('/admin-csp-blog/add/category', [CategoryController::class, 'store'])->name('admin-csp-blog.add.category');
    Route::post('/admin-csp-blog/delete/category', [CategoryController::class, 'destroy'])->name('admin-csp-blog.cat.delete');
    Route::get('/admin-csp-blog/edit/category/{id}', [CategoryController::class, 'edit']);
    Route::post('/admin-csp-blog/update/category/{id}', [CategoryController::class, 'update']);
    // Post
    Route::get('/admin-csp-blog/add/post', [PostController::class, 'create'])->name('admin-csp-blog.add.post');
    Route::post('/admin-csp-blog/store/post', [PostController::class, 'store'])->name('admin-csp-blog.store.post');
    Route::get('/admin-csp-blog/post_listing', [PostController::class, 'index'])->name('admin-csp-blog.list.post');
    Route::get('/admin-csp-blog/post/edit/{id}', [PostController::class, 'edit']);
    Route::post('/admin-csp-blog/post/update/{id}', [PostController::class, 'update']);
    Route::post('/admin-csp-blog/post/delete/{id}', [PostController::class, 'destroy']);

    // Comments
    Route::get('/admin-csp-blog/comments/', [CommentController::class, 'index']);
    Route::get('/admin-csp-blog/comment/update/{status}/{id}', [CommentController::class, 'update']);
    Route::post('/admin-csp-blog/comment/delete/{id}', [CommentController::class, 'destroy']);
});

// Front End

Route::get('/', [FrontController::class, 'index']);
Route::get('/blog/single-post/{slug}', [FrontController::class, 'showCategory_letest_posts']);
Route::get('/blog/category/{slug}/{id}', [FrontController::class, 'showPostbyCategory']);
Route::post('/blog/comment/{slug}/{id}', [FrontController::class, 'storeComment']);
