<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;


class FrontController extends Controller
{
    public function index()
    {
        $post['data'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->orderBy('posts.id', 'DESC')->paginate('6');
        $post['category'] = DB::table('categories')->get();
        //dd($post);
        return view('front.index', $post);
    }
    public function showPostbyCategory(Request $request, $slug, $id)
    {

        $post['data'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->where('posts.cat_id', '=', $id)->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->orderBy('posts.id', 'DESC')->paginate('6');
        $post['category'] = DB::table('categories')->get();

        //dd($post);
        return view('front.postbycategory', $post);
    }


    public function showCategory_letest_posts(Request $request, $slug)
    {
        $post['data'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->where('title', '=', $slug)->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->get();

        $post['comments'] = DB::table('comments')->join('posts', 'posts.id', '=', 'comments.post_id')->where('title', '=', $slug)->where('status', '=', '1')->select('comments.*', 'posts.*')->get();

        $post['lposts'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->orderBy('posts.id', 'DESC')->limit('4')->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->get();

        $post['category'] = DB::table('categories')->get();
        //$post['comments'] = DB::table('comments')->orderBy('comments.id', 'DESC')->get();
        //dd($post['data']);

        return view('front.single', $post);
        // echo "hello";
    }

    public function storeComment(Request $request, $slug, $id)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email',
            'comment' => 'required',
        ]);
        if ($request->post('website') == '') {
            DB::table('comments')->insert([

                'uname' => $request->post('name'),
                'email' => $request->post('email'),
                'website' => 'Null',
                'comment' => $request->post('comment'),
                'post_id' => $id,

            ]);
        } else {
            DB::table('comments')->insert([

                'uname' => $request->post('name'),
                'email' => $request->post('email'),
                'website' => $request->post('website'),
                'comment' => $request->post('comment'),
                'post_id' => $id,

            ]);
        }

        return redirect('/blog/single-post/' . $slug)->with('msg', 'Comment successfull, your comment will appear after approval.');
    }
}
