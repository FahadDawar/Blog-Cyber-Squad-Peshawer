<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $comments['data'] = DB::table('comments')->join('posts', 'comments.post_id', '=', 'posts.id')->select('comments.*', 'posts.title')->get();

        //$comments = DB::table('comments')->orderBy('id', 'DESC')->get();
        //dd($comments);
        return view('admin.comments', $comments);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Comment  $commet
     * @return \Illuminate\Http\Response
     */
    public function show(Comment $commet)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Comment  $commet
     * @return \Illuminate\Http\Response
     */
    public function edit(Comment $commet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Comment  $Comment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $status, $id, Comment $Comment)
    {

        //dd($status);
        if ($status == 'approve') {

            DB::table('comments')->where('id', $id)->update([
                'status' => 1
            ]);
        } else {
            DB::table('comments')->where('id', $id)->update([

                'status' => 0
            ]);
        }
        return redirect('/admin-csp-blog/comments/');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Comment  $Comment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Comment $Comment, $id)
    {
        DB::table('comments')->where('id', $id)->delete();
        return redirect('/admin-csp-blog/comments/')->with('commentdeleted', 'Comment deleted');
    }
}
