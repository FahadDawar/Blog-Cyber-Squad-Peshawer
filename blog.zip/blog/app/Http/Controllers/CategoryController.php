<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;



class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cat = DB::table('categories')->orderBy('id', 'DESC')->get();
        return view('admin.add_category')->with('cats', $cat);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([

            'name' => 'required'
        ]);

        DB::table('categories')->insert([
            'cat_name' => $request->post('name'),
        ]);
        // $res = new Category;
        // $res->cat_name = $request->post('name');
        // $res->save();
        return redirect('/admin-csp-blog/add_category')->with('cat_add_success', 'Category Added');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id, Category $category)
    {

        //  $id = $request->input($id);
        $cat['data'] = DB::table('categories')->where('id', $id)->get();
        // echo "<pre>";
        // print_r($cat);
        // die;
        return view('admin.edit_category', $cat);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id, Category $category)
    {
        $request->validate([

            'name' => 'required',
        ]);
        //echo $id;
        $name = $request->input('name');
        DB::table('categories')->where('id', $id)->update([
            'cat_name' => $name
        ]);
        return redirect('/admin-csp-blog/add_category')->with('success', 'Category updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Category $category)
    {
        // $id = $request->post('id');
        // $cat = Category::where('id', '=', $id);
        // $cat->delete();
        DB::table('categories')->where('id', $request->post('id'))->delete();
        return redirect('/admin-csp-blog/add_category')->with('deleted', 'Categroy deleted');
    }
}
