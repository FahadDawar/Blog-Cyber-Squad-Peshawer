<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        return view('admin.index');
    }

    public function User_view()
    {

        $users['data'] = Admin::all();
        //dd($users);
        return view('admin.add_user', $users);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        if ($request->session()->has('ADMIN_CSP_BLOG_ID')) {

            return redirect('/admin-csp-blog/');
        }
        return view('admin.login');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([

            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:3|max:50',
            'confirm_password' => 'required|min:3|max:50',
            'usertype' => 'required'
        ]);

        $check = DB::table('admins')->where('email', '=', $request->post('email'))->first();
        if ($check) {
            return redirect('/admin-csp-blog/add_user')->with('error', 'Email exist already');
        } else {

            $res = new Admin();
            if ($request->post('password') == $request->post('confirm_password')) {
                $res->name = $request->post('name');
                $res->email = $request->post('email');
                $res->role = $request->post('usertype');
                $res->status = 1;
                $res->password = Hash::make($request->post('password'));
                $res->save();
                return redirect('/admin-csp-blog/add_user')->with('admin_user_add_success', 'User Registered successfully');
            } else {
                return redirect('/admin-csp-blog/add_user')->with('admin_user_add_error', 'Password Unmatched');
            }
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function editStatus(Request $request, $id)
    {


        $activeid = $request->post('id');

        if ($id == $activeid) {
            return redirect('/admin-csp-blog/add_user')->with('msg', 'Active user status can not be update');
        } elseif ($request->post('name') == 'active') {
            Admin::where('id', '=', $id)->update([
                'status' => 1
            ]);
            return redirect('/admin-csp-blog/add_user');
        } else {
            Admin::where('id', '=', $id)->update([
                'status' => 0
            ]);
            return redirect('/admin-csp-blog/add_user');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Admin_auth(Request $request)
    {
        //validate user
        $request->validate([

            'email' => 'required|email',
            'password' => 'required'

        ]);
        // $email = $request->post('email');
        // $password = $request->post('password');
        $result = Admin::where(['email' => $request->post('email')])->first();
        // dd($result);
        //echo Hash::check($password, $result->password);
        if ($result) {
            if (Hash::check($request->post('password'), $result->password) > 0) {

                if ($result->status == 1) {

                    $request->session()->put('ADMIN_CSP_BLOG_ID', $result->id);
                    $request->session()->put('ADMIN_CSP_BLOG_ROLE', $result->role);
                    $request->session()->put('ADMIN_NAME_CSP_BLOG', $result->name);
                    return redirect('/admin-csp-blog/post_listing');
                } else {
                    return redirect('/admin-csp-blog/login')->with('loginerr', 'Sorry you are baned');
                }
            } else {
                // $request->session()->flash('loginerr', 'Invalid login credeintials');
                // return redirect('admin-csp-blog');
                return back()->with('loginerr', 'Invalid login credeintials');
            }
        } else {
            return back()->with('loginerr', 'Invalid login credeintials');
        }
    }


    public function logout()
    {
        if (session()->has('ADMIN_CSP_BLOG_ID')) {
            session()->pull('ADMIN_CSP_BLOG_ID');
            session()->pull('ADMIN_NAME_CSP_BLOG');

            return redirect('/admin-csp-blog/login');
        }
        //return redirect('/admin-csp-blog/login');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Admin $admin)
    {

        $id = $request->post('deletid');
        $activeid = $request->post('activeid');
        if ($id === $activeid) {
            return redirect('/admin-csp-blog/add_user')->with('msg', 'Active user can not be delete');
        } else {
            // $user = Admin::where('id', '=', $id);
            // $user->delete();
            DB::table('admins')->where('id', $id)->delete();
            return redirect('/admin-csp-blog/add_user')->with('msg', 'User deleted');
        }
    }
}
