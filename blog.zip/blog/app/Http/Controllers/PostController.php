<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $posts = DB::table('posts')->orderBy('id', 'DESC')->get();
        // echo session()->has('ADMIN_CSP_BLOG_ID');
        // die;
        $post['data'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->get();
        //$pos['posts'] = Post::all();
        // dd($posts);
        return view('admin.post_listing', $post);
        //return view('admin.post_listing', $post)->with('posts', $post);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $cats = DB::table('categories')->get();

        //dd($posts);
        return view('admin.add_post')->with('cats', $cats);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'cetegory' => 'required',
            'image' => 'required|mimes:png,jpg,jpep'
        ]);

        $newFileName = time() . '.' . $request->image->extension();
        $request->image->move(public_path('images'), $newFileName);

        $post = DB::table('posts')->insert([

            'title' => $request->post('title'),
            'description' => $request->post('description'),
            'image' => $newFileName,
            'cat_id' => $request->post('cetegory'),
            'auther_id' => $request->post('auther_id'),
        ]);
        $request->session()->flash('success', 'Post published successully');
        return redirect('/admin-csp-blog/post_listing');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, Post $post, $id)
    {
        $post['post'] = DB::table('posts')->where('id', $id)->get();
        $post['cat'] = DB::table('categories')->get();
        // $post['data']['cat']; // = $pos['data'];
        //dd($post);

        return view('admin.edit_post', $post);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id, Post $post)
    {
        $request->validate([
            'title' => 'required',
            'description' => 'required',
            'cetegory' => 'required',
            'image' => 'mimes:png,jpg,jpep'
        ]);

        if ($request->hasfile('image')) {

            $newFileName = time() . '.' . $request->image->extension();
            $request->image->move(public_path('images'), $newFileName);

            $postedit = DB::table('posts')->where('id', $id)->update([

                'title' => $request->post('title'),
                'description' => $request->post('description'),
                'image' => $newFileName,
                'cat_id' => $request->post('cetegory'),
                'auther_id' => $request->post('auther_id'),
            ]);
        } else {
            $postedit = DB::table('posts')->where('id', $id)->update([

                'title' => $request->post('title'),
                'description' => $request->post('description'),
                'cat_id' => $request->post('cetegory'),
                'auther_id' => $request->post('auther_id'),
            ]);
        }
        // $post['data'] = DB::table('admins')->join('posts', 'admins.id', '=', 'posts.auther_id')->join('categories', 'posts.cat_id', '=', 'categories.id')->select('categories.*', 'admins.id', 'admins.name', 'posts.*')->get();
        $request->session()->flash('success', 'Post updated successully');
        return redirect('/admin-csp-blog/post_listing');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post, $id)
    {
        DB::table('posts')->where('id', $id)->delete();
        return redirect('/admin-csp-blog/post_listing')->with('msg', 'Post deleted successfully');
    }
}
