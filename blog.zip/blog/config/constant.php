<?php

return [

    'SITE_NAME' => 'Blog | Cyber Squad Peshawer'
];
