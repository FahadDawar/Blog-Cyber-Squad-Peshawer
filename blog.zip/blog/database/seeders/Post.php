<?php


namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class Post extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 20) as $data) {
            DB::table('posts')->insert([

                'title' => $faker->title,
                'description' => $faker->description,
                'cat_id' => $faker->cat_id,
                'image' => $faker->image,
                'auther_id' => $faker->auther_id,

            ]);
        }
    }
}
