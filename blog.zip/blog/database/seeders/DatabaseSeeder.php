<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();
        $faker = Faker::create();
        foreach (range(1, 50) as $data) {
            DB::table('posts')->insert([
                'title' => $faker->title,
                'description' => $faker->description,
                'image' => $faker->image,
                'cat_id' => $faker->cat_id,
                'auther_id' => $faker->auther_id,


            ]);
        }
    }
}
